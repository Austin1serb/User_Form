from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'rootroot' # set a secret key for security purposes

from user_model import Users



@app.route('/users')
def show():
    all_users=Users.get_all()
    print(all_users)

    return render_template("read.html", all_users=all_users)




@app.route('/new', methods=['POST'])
def create_new():

    data = {
        
        'first_name' : request.form['first_name'],
        'last_name' : request.form['last_name'],
        'email' : request.form['email'],
        
    }
    
    new_users = Users.add_user(data)

    print()
    return redirect("/users")





@app.route("/users/new")
def create():

    return render_template("create.html")









if __name__ == "__main__":
    app.run(debug=True, port=5002)
